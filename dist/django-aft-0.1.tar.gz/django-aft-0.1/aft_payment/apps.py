from django.apps import AppConfig


class AftPaymentConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "aft_payment"
